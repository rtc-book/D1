# T1 C Library

This is the T1 C library for the T1 target system. The library archive file is `Debug/libT1.a`.

## Releases 

v0.1.0: With updated `printf_lcd`  
v0.0.1: The basic port from me477

## Old releases

Release: v0.0.1: The original from me477.# T1-source
